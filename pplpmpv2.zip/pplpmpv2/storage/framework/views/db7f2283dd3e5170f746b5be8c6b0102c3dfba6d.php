<?php $__env->startSection('title'); ?>Sign Up
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/sweetalert2.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/select2.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section>
	    <div class="container-fluid p-0">
	        <div class="row m-0">
	            <div class="col-xl-7 p-0"><img class="bg-img-cover bg-center" src="<?php echo e(asset('assets/images/login/1.jpg')); ?>" alt="looginpage" /></div>
	            <div class="col-xl-5 p-0">
	                <div class="login-card">
	                    <form class="theme-form login-form">
	                        <h4>Buat Akun</h4>
	                        <h6>Masukan Data Diri Anda</h6>
	                        
							<div class="form-group">
	                            <label>Nama</label>
	                            <div class="input-group">
	                                <span class="input-group-text"><i class="icon-user"></i></span>
	                                <input class="form-control" type="email" required="" placeholder="Nama Lengkap" />
	                            </div>
	                        </div>
							<div class="form-group">
	                            <label>NIM</label>
	                            <div class="input-group">
	                                <span class="input-group-text"><i class="icon-user"></i></span>
	                                <input class="form-control" type="email" required="" placeholder="NIM" />
	                            </div>
	                        </div>
							<div class="form-group">
	                            <label class="col-form-label">Prodi</label>
	                            <div class="input-group">
	                                <select class="js-example-basic-single col-sm-12">
										<i class="icon-user"></i>
										<optgroup label="Developer">
											<option value="AL">Alabama</option>
											<option value="WY">Wyoming</option>
										</optgroup>
										<optgroup label="Designer">
											<option value="WY">Peter</option>
											<option value="WY">Hanry Die</option>
											<option value="WY">John Doe</option>
										</optgroup>
									</select>
	                            </div>
	                        </div>
	                        <div class="form-group">
	                            <label>Alamat Email</label>
	                            <div class="input-group">
	                                <span class="input-group-text"><i class="icon-email"></i></span>
	                                <input class="form-control" type="email" required="" placeholder="Test@gmail.com" />
	                            </div>
	                        </div>
	                        <div class="form-group">
	                            <label>Password</label>
	                            <div class="input-group">
	                                <span class="input-group-text"><i class="icon-lock"></i></span>
	                                <input class="form-control" type="password" name="login[password]" required="" placeholder="*********" />
	                                <div class="show-hide"><span class="show"> </span></div>
	                            </div>
	                        </div>
	                        
	                        <div class="form-group">
	                            <button class="btn btn-primary btn-block" type="submit">Buat Akun</button>
	                        </div>
	                        
	                        <p>Already have an account?<a class="ms-2" href="<?php echo e(route('login')); ?>">Sign in</a></p>
	                    </form>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>


    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/sweet-alert/sweetalert.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/select2/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/select2/select2-custom.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.authentication.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pplpmpv2\resources\views/daftar/daftar-ppl.blade.php ENDPATH**/ ?>