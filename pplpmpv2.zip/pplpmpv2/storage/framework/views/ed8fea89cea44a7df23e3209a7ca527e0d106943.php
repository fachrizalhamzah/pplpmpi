<?php $__env->startSection('title'); ?>Tambah Ploting
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/select2.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/daterange-picker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
	<?php $__env->startComponent('components.breadcrumb'); ?>
		<?php $__env->slot('breadcrumb_title'); ?>
			<h3>Tambah Ploting Dosen Pamong</h3>
		<?php $__env->endSlot(); ?>
		
	<?php echo $__env->renderComponent(); ?>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">												
				<div class="card">
					<div class="card-header pb-0">
						<h5>Tambah Ploting Dosen Pamong</h5>
					</div>
					<form class="form theme-form">
						<div class="card-body">
							<div class="mb-2">
                                <label class="col-form-label">Nama Dosen Pamong</label>
                                <select class="js-example-basic-single col-sm-12">
                                    <optgroup label="Developer">
                                        <option value="AL">Alabama</option>
                                        <option value="WY">Wyoming</option>
                                    </optgroup>
                                    <optgroup label="Designer">
                                        <option value="WY">Peter</option>
                                        <option value="WY">Hanry Die</option>
                                        <option value="WY">John Doe</option>
                                    </optgroup>
                                </select>
                            </div>
							<div class="mb-2">
                                <label class="col-form-label">Nama Mahasiswa</label>
                                <select class="js-example-basic-single col-sm-12">
                                    <optgroup label="Developer">
                                        <option value="AL">Alabama</option>
                                        <option value="WY">Wyoming</option>
                                    </optgroup>
                                    <optgroup label="Designer">
                                        <option value="WY">Peter</option>
                                        <option value="WY">Hanry Die</option>
                                        <option value="WY">John Doe</option>
                                    </optgroup>
                                </select>
                            </div>
							<div class="row">
								<div class="col">
									<div class="mb-3">
										<label class="form-label" for="exampleInputPassword22">Prodi</label>
										<input class="form-control" id="exampleInputPassword22" type="text" disabled="" placeholder="Prodi" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="mb-3">
										<label class="form-label" for="exampleInputPassword22">Penempatan/Instansi</label>
										<input class="form-control" id="exampleInputPassword22" type="text" disabled="" placeholder="Penempatan/Instansi" />
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<button class="btn btn-primary" type="submit">Submit</button>
							<input class="btn btn-light" type="reset" value="Cancel" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	
	<?php $__env->startPush('scripts'); ?>
	<script src="<?php echo e(asset('assets/js/select2/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/select2/select2-custom.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/datepicker/daterange-picker/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker/daterange-picker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker/daterange-picker/daterange-picker.custom.js')); ?>"></script>
	<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pplpmpv2\resources\views/admin/admin-tambah-ploting-dosen-pamong.blade.php ENDPATH**/ ?>