<?php $__env->startSection('title'); ?>Tambah Mahasiswa
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
	<?php $__env->startComponent('components.breadcrumb'); ?>
		<?php $__env->slot('breadcrumb_title'); ?>
			<h3>Tambah Mahasiswa</h3>
		<?php $__env->endSlot(); ?>
		
        <li class="breadcrumb-item active">Tambah Mahasiswa</li>
	<?php echo $__env->renderComponent(); ?>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="card">
					<div class="card-header pb-0">
						<h5>Form Tambah Mahasiswa</h5>
					</div>
					<form class="form theme-form">
						<div class="card-body">
							<div class="row">
								<div class="col">
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">NIM</label>
										<div class="col-sm-9">
											<input class="form-control" type="text" placeholder="NIM" />
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Nama</label>
										<div class="col-sm-9">
											<input class="form-control" type="text" placeholder="Nama" />
										</div>
									</div>
									<div class="mb-3 row">
										<div class="col">
											<div class="row">
												<label class="col-sm-3 col-form-label">Prodi</label>
												<div class="col-sm-9">
													<select class="custom-select form-select">
														<option selected="">-Prodi-</option>
														<option value="1">One</option>
														<option value="2">Two</option>
														<option value="3">Three</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="mb-3 row">
										<div class="col">
											<div class="row">
												<label class="col-sm-3 col-form-label">Jenis Kelamin</label>
												<div class="col-sm-9">
													<select class="custom-select form-select">
														<option selected="">-Jenis Kelamin-</option>
														<option value="1">Laki-Laki</option>
														<option value="2">Perempuan</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Tanggal Lahir</label>
										<div class="col-sm-9">
											<input class="form-control digits" type="date" value="2022-01-01" />
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Nomor Telepon</label>
										<div class="col-sm-9">
											<input class="form-control" type="text" placeholder="Nomor Telepon" />
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Email</label>
										<div class="col-sm-9">
											<input class="form-control" type="text" placeholder="Email" />
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Alamat</label>
										<div class="col-sm-9">
											<textarea class="form-control" rows="5" cols="5" placeholder="Alamat"></textarea>
										</div>
									</div>
									<div class="mb-3 row">
										<div class="col">
											<div class="row">
												<label class="col-sm-3 col-form-label">Dosen Pembimbing</label>
												<div class="col-sm-9">
													<select class="custom-select form-select">
														<option selected="">-Dosen Pembimbing-</option>
														<option value="1">Laki-Laki</option>
														<option value="2">Perempuan</option>
													</select>
												</div>
											</div>
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Peropde PLP/PMPI/PPL</label>
										<div class="col-sm-9">
											<input class="form-control" type="text" placeholder="* exp : 2022/2023" />
										</div>
									</div>
									<div class="mb-3 row">
										<div class="col">
											<div class="mb-3 row">
												<label class="col-sm-3 col-form-label">Foto</label>
												<div class="col-sm-9">
													<input class="form-control" type="file" />
												</div>
											</div>
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Username</label>
										<div class="col-sm-9">
											<input class="form-control" type="text" placeholder="Username" />
										</div>
									</div>
									<div class="mb-3 row">
										<label class="col-sm-3 col-form-label">Password</label>
										<div class="col-sm-9">
											<input class="form-control" type="password" placeholder="Password" />
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer text-end">
							<div class="col-sm-9 offset-sm-3">
								<button class="btn btn-primary" type="submit">Submit</button>
								<input class="btn btn-light" type="reset" value="Cancel" />
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	
	<?php $__env->startPush('scripts'); ?>
	<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pplpmpv2\resources\views/admin/admintambahmahasiswa.blade.php ENDPATH**/ ?>