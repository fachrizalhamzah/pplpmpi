<?php $__env->startSection('title'); ?>Penilaian Instansi
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/date-picker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
	<?php $__env->startComponent('components.breadcrumb'); ?>
		<?php $__env->slot('breadcrumb_title'); ?>
			<h3>Periode Penilaian Instansi</h3>
		<?php $__env->endSlot(); ?>
		<li class="breadcrumb-item">Periode Penilaian Instansi</li>
		
	<?php echo $__env->renderComponent(); ?>
	
	<div class="container-fluid">
		<div class="card">
			<div class="card-header">
				<h5>Penilaian Instansi</h5>
			</div>
			<div class="card-body">
				<div class="row">
					<div class="col-md-12">
						<div class="date-picker">
							<form class="theme-form">
								<div class="mb-3 row">
									<label class="col-sm-3 col-form-label text-end">Batas Untuk</label>
									<div class="col-xl-5 col-sm-9">
										<div class="input-group">
											<input class="form-control" type="text" disabled="" placeholder="Instansi" />
										</div>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-sm-3 col-form-label text-end">Tanggal Mulai Penilaian</label>
									<div class="col-xl-5 col-sm-9">
										<div class="input-group">
											<input class="datepicker-here form-control digits" type="text" data-language="en" />
										</div>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-sm-3 col-form-label text-end">Tanggal Akhir Penilaian</label>
									<div class="col-xl-5 col-sm-9">
										<div class="input-group">
											<input class="datepicker-here form-control digits" type="text" data-language="en" />
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
	<?php $__env->startPush('scripts'); ?>
	<script src="<?php echo e(asset('assets/js/datepicker/date-picker/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker/date-picker/datepicker.en.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker/date-picker/datepicker.custom.js')); ?>"></script>
	<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pplpmpv2\resources\views/admin/admin-periode-penilaian-instansi.blade.php ENDPATH**/ ?>