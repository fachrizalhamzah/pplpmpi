<header class="main-nav">
    <div class="sidebar-user text-center">
        <a class="setting-primary" href="javascript:void(0)"><i data-feather="settings"></i></a><img class="img-90 rounded-circle" src="<?php echo e(asset('assets/images/dashboard/1.png')); ?>" alt="" />
        <div class="badge-bottom"><span class="badge badge-primary">Admin</span></div>
        <a href="user-profile"> <h6 class="mt-3 f-14 f-w-600">LAB FTK</h6></a>
        <p class="mb-0 font-roboto">UIN Sunan Ampel Surabaya</p>
        
    </div>
    <nav>
        <div class="main-navbar">
            <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
            <div id="mainnav">
                <ul class="nav-menu custom-scrollbar">
                    <li class="back-btn">
                        <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
                    </li>
                    <li class="sidebar-main-title">
                        <div>
                            <h6>General</h6>
                        </div>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="home"></i><span>Dashboard</span></a>                  
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('index')); ?>">Menu</a></li>
                            <li><a href="<?php echo e(route('dashboard-02')); ?>">Home</a></li>
                        </ul>
                    </li>
                    <li class="sidebar-main-title">
                        <div>
                            <h6>Components</h6>
                        </div>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="box"></i><span>Mahasiswa</span></a>
                        <ul class="nav-submenu menu-content">
                            <li>
                                <a class="submenu-title  <?php echo e(in_array(Route::currentRouteName(), ['admin_data_mahasiswa_plp1','admin-data-mahasiswa-plp2','admin-data-mahasiswa-pmpi1','admin-data-mahasiswa-pmpi2']) ? 'active' : ''); ?>" href="javascript:void(0)">
                                    Data Mahasiswa<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span>
                                </a>
                                <ul class="nav-sub-childmenu submenu-content" style="display: <?php echo e(in_array(Route::currentRouteName(), ['admin_data_mahasiswa_plp1','admin-data-mahasiswa-plp2','admin-data-mahasiswa-pmpi1','admin-data-mahasiswa-pmpi2']) ? 'block' : 'none'); ?>;">
                                    <li><a href="<?php echo e(route('admin_data_mahasiswa_plp1')); ?>">PLP I</a></li>
                                    <li><a href="<?php echo e(route('admin-data-mahasiswa-plp2')); ?>">PLP II</a></li>
                                    <li><a href="<?php echo e(route('admin-data-mahasiswa-pmpi1')); ?>">PMPI I</a></li>
                                    <li><a href="<?php echo e(route('admin-data-mahasiswa-pmpi2')); ?>">PMPI II</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('admin-tambah-mahasiswa')); ?>">Tambah Mahasiswa</a></li>
                            <li>
                                <a class="submenu-title  <?php echo e(in_array(Route::currentRouteName(), ['login','daftar-ppl']) ? 'active' : ''); ?>" href="javascript:void(0)">
                                    Tabs<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span>
                                </a>
                                <ul class="nav-sub-childmenu submenu-content" style="display: <?php echo e(in_array(Route::currentRouteName(), ['login','daftar-ppl']) ? 'block' : 'none'); ?>;">
                                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                    <li><a href="<?php echo e(route('daftar-ppl')); ?>">Daftar</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="folder-plus"></i><span>Prodi</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('admin-data-prodi')); ?>">Data Prodi</a></li>
                            <li><a href="<?php echo e(route('admin-tambah-prodi')); ?>">Tambah Prodi</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="edit-3"></i><span>Dosen</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('admin-data-dosen')); ?>">Data Dosen</a></li>
                            <li><a href="<?php echo e(route('admin-tambah-dosen')); ?>">Tambah Dosen</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="cloud-drizzle"></i><span>Instansi</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('admin-data-instansi')); ?>">Data Instansi</a></li>
                            <li><a href="<?php echo e(route('admin-tambah-instansi')); ?>">Tambah Instansi</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="command"></i><span>Dosen Pamong</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('admin-data-dpl')); ?>">Data Dosen Pamong</a></li>
                            <li><a href="<?php echo e(route('admin-tambah-dpl')); ?>">Tambah Dosen Pamong</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="command"></i><span>Penempatan</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('admin-data-penempatan')); ?>">Data Penempatan</a></li>
                            <li><a href="<?php echo e(route('admin-tambah-penempatan')); ?>">Tambah Penempatan</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="box"></i><span>Ploting</span></a>
                        <ul class="nav-submenu menu-content">
                            <li>
                                <a class="submenu-title  <?php echo e(in_array(Route::currentRouteName(), ['admin-data-ploting-dosen','admin-tambah-ploting-dosen']) ? 'active' : ''); ?>" href="javascript:void(0)">
                                    Dosen Pembimbing<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span>
                                </a>
                                <ul class="nav-sub-childmenu submenu-content" style="display: <?php echo e(in_array(Route::currentRouteName(), ['admin-data-ploting-dosen','admin-tambah-ploting-dosen']) ? 'block' : 'none'); ?>;">
                                    <li><a href="<?php echo e(route('admin-data-ploting-dosen')); ?>">Ploting Dosen</a></li>
                                    <li><a href="<?php echo e(route('admin-tambah-ploting-dosen')); ?>">Tambah Ploting Dosen</a></li>
                                </ul>
                            </li>
                            <li>
                                <a class="submenu-title  <?php echo e(in_array(Route::currentRouteName(), ['admin-data-ploting-dosen-pamong','admin-tambah-ploting-dosen-pamong']) ? 'active' : ''); ?>" href="javascript:void(0)">
                                    Dosen Pamong<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span>
                                </a>
                                <ul class="nav-sub-childmenu submenu-content" style="display: <?php echo e(in_array(Route::currentRouteName(), ['admin-data-ploting-dosen-pamong','admin-tambah-ploting-dosen-pamong']) ? 'block' : 'none'); ?>;">
                                    <li><a href="<?php echo e(route('admin-data-ploting-dosen-pamong')); ?>">Ploting Dosen Pamong</a></li>
                                    <li><a href="<?php echo e(route('admin-tambah-ploting-dosen-pamong')); ?>">Tambah Ploting Dosen Pamong</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="command"></i><span>Periode Penilaian</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('admin-periode-penilaian-dosen')); ?>">Penilaian Dosen</a></li>
                            <li><a href="<?php echo e(route('admin-periode-penilaian-instansi')); ?>">Penilaian Instansi</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="box"></i><span>Laporan Mahasiswa</span></a>
                        <ul class="nav-submenu menu-content">
                            <li>
                                <a class="submenu-title  <?php echo e(in_array(Route::currentRouteName(), ['tab-bootstrap','tab-material']) ? 'active' : ''); ?>" href="javascript:void(0)">
                                    Laporan Harian<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span>
                                </a>
                                <ul class="nav-sub-childmenu submenu-content" style="display: <?php echo e(in_array(Route::currentRouteName(), ['tab-bootstrap','tab-material']) ? 'block' : 'none'); ?>;">
                                    <li><a href="<?php echo e(route('tab-bootstrap')); ?>">Data Laporan</a></li>
                                    <li><a href="<?php echo e(route('tab-material')); ?>">Tambah Laporan</a></li>
                                </ul>
                            </li>
                            <li>
                                <a class="submenu-title  <?php echo e(in_array(Route::currentRouteName(), ['admin-data-laporan-akhir','tab-material']) ? 'active' : ''); ?>" href="javascript:void(0)">
                                    Laporan Akhir<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span>
                                </a>
                                <ul class="nav-sub-childmenu submenu-content" style="display: <?php echo e(in_array(Route::currentRouteName(), ['admin-data-laporan-akhir','tab-material']) ? 'block' : 'none'); ?>;">
                                    <li><a href="<?php echo e(route('admin-data-laporan-akhir')); ?>">Data Laporan</a></li>
                                    <li><a href="<?php echo e(route('tab-material')); ?>">Tambah Laporan</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="command"></i><span>Nilai</span></a>
                        <ul class="nav-submenu menu-content">
                            <li>
                                <a class="submenu-title  <?php echo e(in_array(Route::currentRouteName(), ['admin-data-nilai-mahasiswa-instansi','admin-data-nilai-mahasiswa-dosen']) ? 'active' : ''); ?>" href="javascript:void(0)">
                                    Nilai Mahasiswa<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span>
                                </a>
                                <ul class="nav-sub-childmenu submenu-content" style="display: <?php echo e(in_array(Route::currentRouteName(), ['admin-data-nilai-mahasiswa-instansi','admin-data-nilai-mahasiswa-dosen']) ? 'block' : 'none'); ?>;">
                                    <li><a href="<?php echo e(route('admin-data-nilai-mahasiswa-instansi')); ?>">Nilai Instansi</a></li>
                                    <li><a href="<?php echo e(route('admin-data-nilai-mahasiswa-dosen')); ?>">Nilai Dosen</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('admin-data-nilai-mahasiswa-akhir')); ?>">Nilai Akhir</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="command"></i><span>Evaluasi</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('flag-icon')); ?>">Data Evaluasi</a></li>
                            <li><a href="<?php echo e(route('font-awesome')); ?>">Tambah Evaluasi</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="command"></i><span>Sertifikat</span></a>
                        <ul class="nav-submenu menu-content">
                            <li><a href="<?php echo e(route('flag-icon')); ?>">Data Sertifikat</a></li>
                            <li><a href="<?php echo e(route('font-awesome')); ?>">Tambah Sertifikat Mahasiswa</a></li>
                            <li><a href="<?php echo e(route('font-awesome')); ?>">Tambah Sertifikat Dosen</a></li>
                            <li><a href="<?php echo e(route('font-awesome')); ?>">Tambah Sertifikat Instansi</a></li>
                            <li><a href="<?php echo e(route('font-awesome')); ?>">Tambah Sertifikat Dosen Pamong</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\pplpmpv2\resources\views/layouts/admin/partials/sidebar.blade.php ENDPATH**/ ?>